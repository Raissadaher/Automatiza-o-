import os

from qgis._core import QgsMapLayer, QgsWkbTypes, QgsProject


class EstilosCore:
    def __init__(self):
        self.project = QgsProject.instance()

    def executar(self):
        self.adicionando_estilo_imovel()
        self.adicionando_estilo_app()
        self.adicionando_estilo_rl()
        self.adicionando_estilo_uc()
        self.adicionando_estilo_dano()
        self.adicionando_estilo_licenciada()
        self.adicionando_estilo_restrito()
        self.adicionando_estilo_servidao()
        self.adicionando_estilo_supressao()
        
    def adicionando_estilo_imovel(self):
        area_imovel :QgsMapLayer = self.project.mapLayersByName('Área do imóvel')[0]
        estilo_areaimovel = os.path.join(os.path.dirname(__file__), 'assents', 'Area do imovel.qml')
        print(estilo_areaimovel)
        if area_imovel.geometryType() == QgsWkbTypes.PolygonGeometry:
            area_imovel.loadNamedStyle(estilo_areaimovel)
            area_imovel.triggerRepaint()
    
    def adicionando_estilo_app(self):
        app :QgsMapLayer = self.project.mapLayersByName('Área de preservação permanente')[0]
        print(app.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/APP Total.qml'))
        if app.geometryType() == QgsWkbTypes.PolygonGeometry:
            app.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/APP Total.qml')
            app.triggerRepaint()
  
    def adicionando_estilo_rl(self):
        rl :QgsMapLayer = self.project.mapLayersByName('Reserva legal')[0]
        print(rl.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Reserva legal.qml'))
        if rl.geometryType() == QgsWkbTypes.PolygonGeometry:
            rl.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Reserva legal.qml')
            rl.triggerRepaint()

    def adicionando_estilo_supressao(self):
        area_supressao :QgsMapLayer = self.project.mapLayersByName('Área de supressão')[0]
        print(area_supressao.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area de supressao.qml'))
        if area_supressao.geometryType() == QgsWkbTypes.PolygonGeometry:
            area_supressao.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area de supressao.qml')
            area_supressao.triggerRepaint()

    def adicionando_estilo_dano(self):
        dano :QgsMapLayer = self.project.mapLayersByName('Dano')[0]
        print(dano.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area danificada.qml'))
        if dano.geometryType() == QgsWkbTypes.PolygonGeometry:
            dano.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area danificada.qml')
            dano.triggerRepaint()

    def adicionando_estilo_restrito(self):
        area_uso_restrito :QgsMapLayer = self.project.mapLayersByName('Área de uso restrito')[0]
        print(area_uso_restrito.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area de uso restrito.qml'))
        if area_uso_restrito.geometryType() == QgsWkbTypes.PolygonGeometry:
            area_uso_restrito.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area de uso restrito.qml')
            area_uso_restrito.triggerRepaint()

    def adicionando_estilo_uc(self):
        uc :QgsMapLayer = self.project.mapLayersByName('Unidade de conservação')[0]
        print(uc.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Unidade de Conservacao.qml'))
        if uc.geometryType() == QgsWkbTypes.PolygonGeometry:
            uc.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Unidade de Conservacao.qml')
            uc.triggerRepaint()

    def adicionando_estilo_servidao(self):
        servidao :QgsMapLayer = self.project.mapLayersByName('Servidão administrativa')[0]
        print(servidao.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Servidao administrativa.qml'))
        if servidao.geometryType() == QgsWkbTypes.PolygonGeometry:
            servidao.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Servidao administrativa.qml')
            servidao.triggerRepaint()

    def adicionando_estilo_licenciada(self):
        area_licenciada :QgsMapLayer = self.project.mapLayersByName('Área licenciada')[0]
        print(area_licenciada.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area licenciada.qml'))
        if area_licenciada.geometryType() == QgsWkbTypes.PolygonGeometry:
            area_licenciada.loadNamedStyle('C:/Users/raissa.alves/Documents/Vetores/Estilos_QGIS/Area licenciada.qml')
            area_licenciada.triggerRepaint()


