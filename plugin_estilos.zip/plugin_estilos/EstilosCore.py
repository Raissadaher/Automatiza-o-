import os
from qgis._core import QgsMapLayer, QgsWkbTypes, QgsProject


class EstilosCore:
    def __init__(self):
        self.project = QgsProject.instance()

    def executar(self):
        self.adicionando_estilo_imovel()
        self.adicionando_estilo_app()
        self.adicionando_estilo_rl()
        self.adicionando_estilo_supressao()
        self.adicionando_estilo_dano()
        self.adicionando_estilo_restrito()
        self.adicionando_estilo_uc()
        self.adicionando_estilo_servidao()
        self.adicionando_estilo_licenciada()
        self.adicionando_estilo_embargo()
        self.adicionando_estilo_autuadas()
        self.adicionando_estilo_vereda()
        self.adicionando_estilo_umida()


    def adicionando_estilo_imovel(self):
        area_imovel_list = self.project.mapLayersByName('Área do imóvel')
        if area_imovel_list:
            area_imovel = area_imovel_list[0]
            estilo_areaimovel = os.path.join(os.path.dirname(__file__), 'assents', 'Area do imovel.qml')
            print(estilo_areaimovel)
            if area_imovel.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_imovel.loadNamedStyle(estilo_areaimovel)
                area_imovel.triggerRepaint()

    def adicionando_estilo_app(self):
        app_list = self.project.mapLayersByName('Área de preservação permanente')
        if app_list:
            app = app_list[0]
            estilo_app = os.path.join(os.path.dirname(__file__), 'assents', 'APP Total.qml')
            print(estilo_app)
            if app.geometryType() == QgsWkbTypes.PolygonGeometry:
                app.loadNamedStyle(estilo_app)
                app.triggerRepaint()

    def adicionando_estilo_rl(self):
        rl_list = self.project.mapLayersByName('Reserva legal')
        if rl_list:
            rl = rl_list[0]
            estilo_rl = os.path.join(os.path.dirname(__file__), 'assents', 'Reserva legal.qml')
            print(estilo_rl)
            if rl.geometryType() == QgsWkbTypes.PolygonGeometry:
                rl.loadNamedStyle(estilo_rl)
                rl.triggerRepaint()

    def adicionando_estilo_supressao(self):
        area_supressao_list = self.project.mapLayersByName('Área de supressão')
        if area_supressao_list:
            area_supressao = area_supressao_list[0]
            estilo_supressao = os.path.join(os.path.dirname(__file__), 'assents', 'Area de supressao.qml')
            print(estilo_supressao)
            if area_supressao.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_supressao.loadNamedStyle(estilo_supressao)
                area_supressao.triggerRepaint()

    def adicionando_estilo_dano(self):
        dano_list = self.project.mapLayersByName('Dano')
        if dano_list:
            dano = dano_list[0]
            estilo_dano = os.path.join(os.path.dirname(__file__), 'assents', 'Area danificada.qml')
            print(estilo_dano)
            if dano.geometryType() == QgsWkbTypes.PolygonGeometry:
                dano.loadNamedStyle(estilo_dano)
                dano.triggerRepaint()

    def adicionando_estilo_restrito(self):
        area_uso_restrito_list = self.project.mapLayersByName('Área de uso restrito')
        if area_uso_restrito_list:
            area_uso_restrito = area_uso_restrito_list[0]
            estilo_restrito = os.path.join(os.path.dirname(__file__), 'assents', 'Area de uso restrito.qml')
            print(estilo_restrito)
            if area_uso_restrito.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_uso_restrito.loadNamedStyle(estilo_restrito)
                area_uso_restrito.triggerRepaint()

    def adicionando_estilo_uc(self):
        uc_list = self.project.mapLayersByName('Unidade de conservação')
        if uc_list:
            uc = uc_list[0]
            estilo_uc = os.path.join(os.path.dirname(__file__), 'assents', 'Unidade de Conservacao.qml')
            print(estilo_uc)
            if uc.geometryType() == QgsWkbTypes.PolygonGeometry:
                uc.loadNamedStyle(estilo_uc)
                uc.triggerRepaint()

    def adicionando_estilo_servidao(self):
        servidao_list = self.project.mapLayersByName('Servidão administrativa')
        if servidao_list:
            servidao = servidao_list[0]
            estilo_servidao = os.path.join(os.path.dirname(__file__), 'assents', 'Servidao administrativa.qml')
            print(estilo_servidao)
            if servidao.geometryType() == QgsWkbTypes.PolygonGeometry:
                servidao.loadNamedStyle(estilo_servidao)
                servidao.triggerRepaint()

    def adicionando_estilo_licenciada(self):
        area_licenciada_list = self.project.mapLayersByName('Área licenciada')
        if area_licenciada_list:
            area_licenciada = area_licenciada_list[0]
            estilo_licenciada = os.path.join(os.path.dirname(__file__), 'assents', 'Area licenciada.qml')
            print(estilo_licenciada)
            if area_licenciada.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_licenciada.loadNamedStyle(estilo_licenciada)
                area_licenciada.triggerRepaint()

    def adicionando_estilo_embargo(self):
        area_embargada_list = self.project.mapLayersByName('Área embargada')
        if area_embargada_list:
            area_embargada = area_embargada_list[0]
            estilo_embargada = os.path.join(os.path.dirname(__file__), 'assents', 'Areas embargadas.qml')
            print(area_embargada)
            if area_embargada.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_embargada.loadNamedStyle(estilo_embargada)
                area_embargada.triggerRepaint()


    def adicionando_estilo_autuadas(self):
        area_autuada_list = self.project.mapLayersByName('Área autuada')
        if area_autuada_list:
            area_autuada = area_autuada_list[0]
            estilo_autuada = os.path.join(os.path.dirname(__file__), 'assents', 'Areas autuadas.qml')
            print(area_autuada)
            if area_autuada.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_autuada.loadNamedStyle(estilo_autuada)
                area_autuada.triggerRepaint()


    def adicionando_estilo_vereda(self):
        area_vereda_list = self.project.mapLayersByName('Área de vereda')
        if area_vereda_list:
            area_vereda = area_vereda_list[0]
            estilo_vereda = os.path.join(os.path.dirname(__file__), 'assents', 'Vereda.qml')
            print(area_vereda)
            if area_vereda.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_vereda.loadNamedStyle(estilo_vereda)
                area_vereda.triggerRepaint()


    def adicionando_estilo_umida(self):
        area_umida_list = self.project.mapLayersByName('Área úmida')
        if area_umida_list:
            area_umida = area_umida_list[0]
            estilo_umida = os.path.join(os.path.dirname(__file__), 'assents', 'Area umida.qml')
            print(area_umida)
            if area_umida.geometryType() == QgsWkbTypes.PolygonGeometry:
                area_umida.loadNamedStyle(estilo_umida)
                area_umida.triggerRepaint()